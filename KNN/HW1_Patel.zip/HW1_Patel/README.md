Make sure the folder contains the test_data.txt and train_data.txt in the folder.

Enter `py main.py` in the terminal to run the program or run the program in PyCharm IDE. The PyCharm extension(`.idea`) is provided.

One can find my knn-implementation from line 99 to 115.